public class Piece {
    Piece() {}
    @Override
    public String toString() {
        return "⊗";
    }
}
