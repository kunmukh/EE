public enum Colors {
    RED, BLUE, GREY
}
