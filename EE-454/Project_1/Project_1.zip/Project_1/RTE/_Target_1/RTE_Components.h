
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Project1' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32l4xx.h"

#define RTE_DEVICE_STARTUP_STM32L4XX    /* Device Startup for STM32L4 */

#endif /* RTE_COMPONENTS_H */
