import java.util.ArrayList;

public class Application {
    private ArrayList<Integer> boardAmount = new ArrayList<>();
    private ArrayList<String> boardColor = new ArrayList<>();
    public static void main(String args[]) {
        Gameplay game = new Gameplay();
        game.run();

    }
}










