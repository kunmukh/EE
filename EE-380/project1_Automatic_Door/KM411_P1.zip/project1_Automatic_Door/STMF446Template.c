//Kunal Mukherjee
//Project 1: Automatic Door
//2/16/2019
#include "stm32f446.h"
#include "stm32l476xx.h"
#include <stdio.h>
#include <stdlib.h>

/*stm446Template.c July 1, 2017
*/

//*Global functions	
int getKeyPressed(void);
void delayOne(void);
void delayTwo(void);
void delayTen(void);

//*initialize global constants
int codeInputGottenFirst = 0; //set the 6-digit code
int codeInputGotten = 0;     //get the user input complete
int codeInputStatus = 0;     //flag to see if xode is correct or not

int code [6]; //the got set
int inputCode [6]; //the user input code

int flag1 = 0;
int flag3 = 0;
int flag5 = 0;
int selectIQ = 99;

int main()
 {
	//*Initialize varibales		
	int i;
	int charPres = 99;
	int codeIndexFirst = 0;
	int codeIndex = 0;
	int codeCheck = 0;
	int reset = 0;
	
	//Enabling Clock bits
	RCC_AHB1ENR |= 1;     //Bit 0 is GPIOA clock enable bit
  RCC_AHB1ENR |= 4;     //Bit 3 is GPIOC clock enable bit	
	
	//I/O bits	
	//KeyPad
	GPIOC_MODER &= ~(3 << (2 * 1)); //C1 = input
	GPIOC_MODER &= ~(3 << (2 * 3)); //C3 = input
	GPIOC_MODER &= ~(3 << (2 * 5)); //C5 = input
	
	GPIOC_MODER |= (1 << (2 * 2)); //C2 = output
	GPIOC_MODER |= (1 << (2 * 4)); //C4 = output
	GPIOC_MODER |= (1 << (2 * 6)); //C6 = output
	GPIOC_MODER |= (1 << (2 * 7)); //C7 = output
	
	GPIOC_OTYPER |= (1 << (1 * 2)); //C2 = open-drain
	GPIOC_OTYPER |= (1 << (1 * 4)); //C4 = open-drain
	GPIOC_OTYPER |= (1 << (1 * 6)); //C6 = open-drain
	GPIOC_OTYPER |= (1 << (1 * 7)); //C7 = open-drain	
	
	GPIOC_OSPEEDER |= (2 << (2 * 2)); //C2 = fast-speed
	GPIOC_OSPEEDER |= (2 << (2 * 4)); //C4 = fast-speed
	GPIOC_OSPEEDER |= (2 << (2 * 6)); //C6 = fast-speed
	GPIOC_OSPEEDER |= (2 << (2 * 7)); //C7 = fast-speed	
	//GRIO_PUPDR = reset value is 0, so no pull-up/pull-down
	
	//LED and Solenoid
	GPIOA_MODER |= (1 << (2 * 0)); //A0 = output red
	GPIOA_MODER |= (1 << (2 * 1)); //A1 = output green
	GPIOA_MODER |= (1 << (2 * 6)); //A6 = output red
	GPIOA_MODER |= (1 << (2 * 7)); //A7 = output green
	GPIOA_MODER |= (1 << (2 * 5)); //A5 = output solenoid
	//GPIOA_OTYPER default is push/pull-up/pull-down
	
	GPIOA_OSPEEDER |= (2 << (2 * 0)); //A0 = fast-speed
	GPIOA_OSPEEDER |= (2 << (2 * 1)); //A1 = fast-speed
	GPIOA_OSPEEDER |= (2 << (2 * 6)); //A6 = fast-speed
	GPIOA_OSPEEDER |= (2 << (2 * 7)); //A7 = fast-speed
	GPIOA_OSPEEDER |= (2 << (2 * 5)); //A5 = fast-speed	
	
	//initialization of the code
	for (i = 0; i < 6; i++){code[i] = 99; inputCode[i] = 99;}	

	//turn solenoid off
	GPIOA_ODR |= (1 << (1 * 5)); //A5 = high- Solenoid
	
	//Enable Interrupt
	//Interrupt registers	
	NVIC_EnableIRQ(EXTI1_IRQn);//PC_1
	NVIC_EnableIRQ(EXTI2_IRQn);//PC_3
	NVIC_EnableIRQ(EXTI3_IRQn);//PC_5
	
	//Connect External Line to the GPI
	RCC_APB2ENR |= RCC_APB2ENR_SYSCFGEN;
	
	SYSCFG->EXTICR[0] &= ~SYSCFG_EXTICR1_EXTI1;
	SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI1_PC;
	
	SYSCFG->EXTICR[1] &= ~SYSCFG_EXTICR1_EXTI3;
	SYSCFG->EXTICR[1] |= SYSCFG_EXTICR1_EXTI3_PC;
	
	SYSCFG->EXTICR[2] &= ~SYSCFG_EXTICR2_EXTI5;
	SYSCFG->EXTICR[2] |= SYSCFG_EXTICR2_EXTI5_PC;
	
	//Rising trigger selection
	//0 = trigger disabled, 1 = trigger enabled
	EXTI->RTSR1 |= EXTI_RTSR1_RT1;
	EXTI->RTSR1 |= EXTI_RTSR1_RT3;
	EXTI->RTSR1 |= EXTI_RTSR1_RT5;
	
	//Interrupt Mask Register
	//0 = marked, 1 = not masked (enabled)
	EXTI->IMR1 |= EXTI_IMR1_IM1;
	EXTI->IMR1 |= EXTI_IMR1_IM3;
	EXTI->IMR1 |= EXTI_IMR1_IM5;

	 //Main program loop	 
	 while(1)
	 {
			while (!codeInputGottenFirst) //getting the inout code for the first time
			{
				delayOne();
				if(flag1 || flag3 || flag3)
				{
					charPres = selectIQ;
				}
				
				if (charPres != 99)
				{
					code[codeIndexFirst] = charPres;
					codeIndexFirst++;
					GPIOA_ODR |= (1 << (1 * 0)); //A0 = high; //red
					delayTwo();
					GPIOA_ODR &= ~(1 << (1 * 0)); //A0 = low; //red
				}
				
				if (codeIndexFirst == 6){codeInputGottenFirst = 1;}
			}
			delayTwo();
			GPIOA_ODR |= (1 << (1 * 0)); //A0 = high; //red;
			
			while (!codeInputGotten) //getting the inout code
			{
				delayOne();
				
				if(flag1 || flag3 || flag3)
				{
					charPres = selectIQ;
				}
				
				if (charPres != 99)
				{
					inputCode[codeIndex] = charPres;
					codeIndex++;
					GPIOA_ODR |= (1 << (1 * 1)); //A1 = high;
					delayTwo();
					GPIOA_ODR &= ~(1 << (1 * 1)); //A1 = low;
				}
				
				if (codeIndex == 6){codeInputGotten = 1;}
			}
			
			//check to see reset
			for (i = 0; i < 6; i++)
			{
				if (inputCode[i] != 0)
				{
					reset = 0;
					break;
				}else{
					reset = 1;
				}
			}
			
			if (reset == 0)
			{
					//check to see if code is same
					for (i = 0; i < 6; i++)
					{
						if (code[i] == inputCode[i])
						{
							codeInputStatus = 1;
						}
						else
						{
							codeInputStatus = 0;
							break;
						}
					}
					
					if (codeInputStatus == 1) //code is right
					{
						delayTwo();
						GPIOA_ODR &= ~(1 << (1 * 5)); //A5 = low- Solenoid ON
						for (i = 0; i < 5; i++)
						{
							GPIOA_ODR |= (1 << (1 * 6)); //A6 = high;
							delayTwo();
							GPIOA_ODR &= ~(1 << (1 * 6)); //A6 = low;
							delayTwo();
						}
						delayTen();
						GPIOA_ODR |= (1 << (1 * 5)); //A5 = high- Solenoid OFF
						
					}
					else
					{
						delayTwo();
						for (i = 0; i < 5; i++)
						{
							GPIOA_ODR |= (1 << (1 * 7)); //A7 = red
							delayTwo();
							GPIOA_ODR &= ~(1 << (1 * 7)); //A7 = red
							delayTwo();
						}
					}				
			}else{
					delayTwo();
					GPIOA_ODR &= ~(1 << (1 * 0)); //A0 = high; //red;
					codeInputGottenFirst = 0;
					codeIndexFirst = 0;
					for (i = 0; i < 6; i++){code[i] = 99;}
			}
			
			
			//clear the code entered
			//initialization of the code
			for (i = 0; i < 6; i++){inputCode[i] = 99;}	
			codeIndex = 0;			
			codeInputStatus = 0;
			codeInputGotten = 0;		
			delayOne();
		 
	 }
	 
 } 
  void EXTI1_IRQHandler(void) //C1 = 2
 {
		//check for EXIT 1 interrupt flag
	 if ((EXTI->PR1 & EXTI_PR1_PIF1) == EXTI_PR1_PIF1)
		{
			if(! (GPIOC_IDR & (1 << 2))) //check if C2 is low, 3
			{
				selectIQ = 2;					
			}
			if(! (GPIOC_IDR & (1 << 4))) //check if C4 is low, 5
			{
				selectIQ = 0;					
			}
			if(! (GPIOC_IDR & (1 << 6))) //check if C6 is low, 7
			{
				selectIQ = 8;					
			}
			if(! (GPIOC_IDR & (1 << 7))) //check if C7 is low, 8
			{
				selectIQ = 5;					
			}
			
			flag1 = 1;
			//clear interrupt pending request
			EXTI->PR1 |= EXTI_PR1_PIF1; 
		}		
 }
 
 void EXTI3_IRQHandler(void) //C3 = 4
 {
		//check for EXIT 3 interrupt flag
	 if ((EXTI->PR1 & EXTI_PR1_PIF3) == EXTI_PR1_PIF3)
		{
			if(! (GPIOC_IDR & (1 << 2))) //check if C2 is low, 3
			{
				selectIQ = 1;					
			}
			if(! (GPIOC_IDR & (1 << 4))) //check if C4 is low, 5
			{
				selectIQ = 11;					
			}
			if(! (GPIOC_IDR & (1 << 6))) //check if C6 is low, 7
			{
				selectIQ = 7;					
			}
			if(! (GPIOC_IDR & (1 << 7))) //check if C7 is low, 8
			{
				selectIQ = 4;					
			}
			
			flag3 = 1;
			//clear interrupt pending request
			EXTI->PR1 |= EXTI_PR1_PIF3; 
		}		
 }
 
  void EXTI5_IRQHandler(void) //C5 = 6
 {
		//check for EXIT 5 interrupt flag
	 if ((EXTI->PR1 & EXTI_PR1_PIF5) == EXTI_PR1_PIF5)
		{
			if(! (GPIOC_IDR & (1 << 2))) //check if C2 is low, 3
			{
				selectIQ = 3;					
			}
			if(! (GPIOC_IDR & (1 << 4))) //check if C4 is low, 5
			{
				selectIQ = 10;					
			}
			if(! (GPIOC_IDR & (1 << 6))) //check if C6 is low, 7
			{
				selectIQ = 9;					
			}
			if(! (GPIOC_IDR & (1 << 7))) //check if C7 is low, 8
			{
				selectIQ = 6;					
			}
			
			flag5 = 1;
			//clear interrupt pending request
			EXTI->PR1 |= EXTI_PR1_PIF5; 
		}		
 }
 
  
 void delayOne(void)
 {
	 int i,j;
	 for (i = 0; i < 5000; i++);
	 //for (i = 0; i < 16000; i++){ for (j = 0; j < 250; j++);} //1 sec
 }
 
 void delayTwo(void)
 {
	 int i,j;
	 for (i = 0; i < 16000; i++){ for (j = 0; j < 350; j++);} //1 sec
 }
 
 void delayTen(void)
 {
	int i,j;
	for (i = 0; i < 16000; i++){ for (j = 0; j < 1250; j++);} //10 sec
 }

 
 
